#import <Flutter/Flutter.h>

@interface ProximitySensorPlugin : NSObject<FlutterPlugin>
@end
