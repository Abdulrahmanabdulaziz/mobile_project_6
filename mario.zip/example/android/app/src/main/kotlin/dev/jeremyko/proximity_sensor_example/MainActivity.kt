package dev.jeremyko.proximity_sensor_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
