## 1.0.4

-   ext.kotlin_version = '1.7.20'

## 1.0.2

-   remove debugging logging

## 1.0.1

-   fix : github visibility

## 1.0.0

-   First stable version.
